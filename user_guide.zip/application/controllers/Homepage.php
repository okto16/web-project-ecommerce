<?php
class Homepage extends CI_Controller
{
    public function index()
    {
        $data['title'] = 'Rejeki Sports';
        $this->load->view('Layout Admin', $data);
        $this->load->view('Layout Admin 2');

        $data['tbl_member'] = $this->db->get_where('tbl_member', ['email' => $this->session->userdata('email')])->row_array();

        $this->load->view('Homepage', $data);
    }

    public function logout()
    {
        $this->session->unset_userdata('email');

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Your account has been Logout</div>');
        redirect('login');
    }
}
