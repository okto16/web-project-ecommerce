<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }

    public function index()
    {
        $this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');

        if($this->form_validation->run() == false){
            $data['title'] = 'Rejeki Sports Login';
            $this->load->view('templates/header', $data);
            $this->load->view('Login');
            $this->load->view('templates/footer');
        } else {
            //validasi success
            $this->login();
        }
    }

    private function login()
    {
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $tbl_member = $this->db->get_where('tbl_member', ['email' => $email])->row_array();
        var_dump($tbl_member);
        if($tbl_member) {
            //usernya aktif
            if($tbl_member['statusAktif'] == 'Y') {

                if(password_verify($password, $tbl_member['password'])){
                    $data = [
                        'email' => $tbl_member['email']
                    ];
                    $this->session->set_userdata($data);
                    redirect('Homepage');
                }else {
                    $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Wrong password!</div>');
                    redirect('login');
                }

            }else{
                $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Email has not activated!</div>');
            redirect('login');
            }
        }else{
            $this->session->set_flashdata('message','<div class="alert alert-danger" role="alert">Email is not register!</div>');
            redirect('login');
        }
    }

    public function Registrasi()
    {
        $this->form_validation->set_rules('username', 'UserName', 'required|trim');
        $this->form_validation->set_rules('namaKonsumen', 'Name', 'required|trim');
        $this->form_validation->set_rules('alamat', 'Address', 'required|trim');
        $this->form_validation->set_rules('tlpn', 'No Telepon', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[tbl_member.email]',[
            'is_unique' => 'This email has already registered!'
        ]);
        $this->form_validation->set_rules('password', 'Password', 'required|trim|min_length[5]');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Rejeki Sports Registration';
            $this->load->view('templates/header', $data);
            $this->load->view('Registrasi');
            $this->load->view('templates/footer');
        } else {
            $data = [
                'username' => $this->input->post('username'),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'namaKonsumen' => $this->input->post('namaKonsumen'),
                'alamat' => $this->input->post('alamat'),
                'email' => $this->input->post('email'),
                'tlpn' => $this->input->post('tlpn'),
                'statusAktif' => 'Y'
            ];
            $this->db->insert('tbl_member', $data);
            $this->session->set_flashdata('message','<div class="alert alert-success" role="alert">Your account has been created!</div>');
            redirect('login');
        }
    }
}
